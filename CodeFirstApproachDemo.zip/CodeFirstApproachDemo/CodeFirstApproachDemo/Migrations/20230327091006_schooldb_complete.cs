﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeFirstApproachDemo.Migrations
{
    public partial class schooldb_complete : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Students_Grades_GradeID",
                table: "Students");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Students",
                table: "Students");

            migrationBuilder.RenameTable(
                name: "Students",
                newName: "tblStudent");

            migrationBuilder.RenameIndex(
                name: "IX_Students_GradeID",
                table: "tblStudent",
                newName: "IX_tblStudent_GradeID");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "tblStudent",
                type: "varchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true)
                .Annotation("Relational:ColumnOrder", 1);

            migrationBuilder.AddColumn<string>(
                name: "EmailID",
                table: "tblStudent",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Stud_AddressStudentAddressID",
                table: "tblStudent",
                type: "int",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_tblStudent",
                table: "tblStudent",
                column: "RollNo");

            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    StudentAddressID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StreetNo = table.Column<int>(type: "int", nullable: false),
                    StreetName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StudAddressStudentAddressID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.StudentAddressID);
                    table.ForeignKey(
                        name: "FK_Address_Address_StudAddressStudentAddressID",
                        column: x => x.StudAddressStudentAddressID,
                        principalTable: "Address",
                        principalColumn: "StudentAddressID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblStudent_Stud_AddressStudentAddressID",
                table: "tblStudent",
                column: "Stud_AddressStudentAddressID");

            migrationBuilder.CreateIndex(
                name: "IX_Address_StudAddressStudentAddressID",
                table: "Address",
                column: "StudAddressStudentAddressID");

            migrationBuilder.AddForeignKey(
                name: "FK_tblStudent_Address_Stud_AddressStudentAddressID",
                table: "tblStudent",
                column: "Stud_AddressStudentAddressID",
                principalTable: "Address",
                principalColumn: "StudentAddressID");

            migrationBuilder.AddForeignKey(
                name: "FK_tblStudent_Grades_GradeID",
                table: "tblStudent",
                column: "GradeID",
                principalTable: "Grades",
                principalColumn: "GradeID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tblStudent_Address_Stud_AddressStudentAddressID",
                table: "tblStudent");

            migrationBuilder.DropForeignKey(
                name: "FK_tblStudent_Grades_GradeID",
                table: "tblStudent");

            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tblStudent",
                table: "tblStudent");

            migrationBuilder.DropIndex(
                name: "IX_tblStudent_Stud_AddressStudentAddressID",
                table: "tblStudent");

            migrationBuilder.DropColumn(
                name: "EmailID",
                table: "tblStudent");

            migrationBuilder.DropColumn(
                name: "Stud_AddressStudentAddressID",
                table: "tblStudent");

            migrationBuilder.RenameTable(
                name: "tblStudent",
                newName: "Students");

            migrationBuilder.RenameIndex(
                name: "IX_tblStudent_GradeID",
                table: "Students",
                newName: "IX_Students_GradeID");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Students",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(40)",
                oldMaxLength: 40)
                .OldAnnotation("Relational:ColumnOrder", 1);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Students",
                table: "Students",
                column: "RollNo");

            migrationBuilder.AddForeignKey(
                name: "FK_Students_Grades_GradeID",
                table: "Students",
                column: "GradeID",
                principalTable: "Grades",
                principalColumn: "GradeID");
        }
    }
}
