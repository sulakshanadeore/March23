﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeFirstApproachDemo.Migrations
{
    public partial class schooldb_complete1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Address_Address_StudAddressStudentAddressID",
                table: "Address");

            migrationBuilder.DropIndex(
                name: "IX_Address_StudAddressStudentAddressID",
                table: "Address");

            migrationBuilder.DropColumn(
                name: "StudAddressStudentAddressID",
                table: "Address");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "StudAddressStudentAddressID",
                table: "Address",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Address_StudAddressStudentAddressID",
                table: "Address",
                column: "StudAddressStudentAddressID");

            migrationBuilder.AddForeignKey(
                name: "FK_Address_Address_StudAddressStudentAddressID",
                table: "Address",
                column: "StudAddressStudentAddressID",
                principalTable: "Address",
                principalColumn: "StudentAddressID");
        }
    }
}
