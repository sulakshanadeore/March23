﻿using CodeFirstApproachDemo.Models;
using System;

namespace CodeFirstApproachDemo // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
            using (var context=new SchoolDbContext())
            {


                //var d = new Course() { CourseName="C++",CourseDuration=25 };
                //context.Add(d);
                //context.SaveChanges();
                var det = context.Courses.Find(1);
                Console.WriteLine(det.CourseID);
                Console.WriteLine(det.CourseName);
                Console.WriteLine(det.CourseDuration);
                det.CourseName = "C Prog";
                det.CourseDuration = 25;
                context.Courses.Update(det);
                context.SaveChanges();
                Console.WriteLine("done");
            }
        }
    }
}