﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstApproachDemo.Models
{
    [Table("tblStudent")]
    public class Student
    {
        [Key]                              
        public int RollNo { get; set; }

        [StringLength(40, ErrorMessage ="Name can't be greater than 40 characters..")]       
        [DataType(DataType.Text, ErrorMessage ="Name can only be a string..")]
        [Column(Order =3,TypeName ="varchar")]                                   
        [Required(AllowEmptyStrings = false, ErrorMessage ="Name is a required field..")]
        public string? Name { get; set; }
        public Grade? Grade { get; set; }             
        public Address? Stud_Address { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage ="Invalid Email Address..")]
        public string? EmailID { get; set; }

    }

    public class Course
    {
        [Key]
        public int CourseID { get; set; }
        public string CourseName { get; set; } = null!;
        //public double Fees { get; set; }
        public int CourseDuration { get; set; }
    }

    public class Grade
    {
        [Key]
        public int GradeID { get; set;}
        public string GradeName { get; set; } = null!;
        public virtual ICollection<Student>? Students { get; set; }
    }

    public class Address
    {
        public int StreetNo { get; set; }
        
        
        public string? StreetName { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Country { get; set; }
        [Key]
        public int StudentAddressID { get; set; }
       // public Address? StudAddress { get; set; }

    }

    public class SchoolDbContext : DbContext
    {
       /* public SchoolDbContext()
        {

        }*/

        public virtual DbSet<Grade> Grades { get; set; }
        public virtual DbSet<Course> Courses { get; set; }
        public virtual DbSet<Student> Students { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(@"Server = M5387503\SQLEXPRESS; database=SchoolDb; integrated security=true");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Address>()
       .HasIndex(u => u.StreetName)
       .IsUnique();
        }
    }
    
}

